package ClubZed;

import java.util.Random;
/**
 * <pre>
 * Programmer: Constantin Buruiana
 * Date: February 12, 2018
 * Purpose: First practice of the arrays using ZigNag class.
 * </pre>
 * @author constbur
 */
public class ClubZed extends Object
{
    private ZigNag[] members;
    private int currentSize;
    private final static int SEED = 47;
    private final static Random RAND = new Random(SEED);
    private final static String ALPHABET = 
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!@$%.&*+-/=";
    
    /**
     * <pre>
     * Defualt constructor.
     * Creates an array of ZigNags of length 1
     * and sets the currentSize to 0.
     * </pre>
     */
    public ClubZed()
    {
        this.members = new ZigNag[1];
        this.currentSize = 0;
    }
    
    /**
     * Returns true if this ClubZed's currentSize equals to 0.
     * @return this.currentSize == 0
     */
    public boolean isEmpty()
    {
        return (this.currentSize == 0);
    }
    
    /**
     * Returns true if this ClubZed's currentSize equals to its length.
     * @return this.currentSize == this.members.length
     */
    public boolean isFull()
    {
        return (this.currentSize == this.members.length);
    }
    
    /**
     * Returns the length of this ClubZed.
     * @return this.members.length
     */
    public int capacity()
    {
        return this.members.length;
    }
    
    /**
     * Returns the number of members of this ClubZed.
     * @return this.currentSize
     */
    public int size()
    {
        return this.currentSize;
    }
    
    /**
     * Prints each member of this ClubZed using ZigNag's toString().
     * @return String
     */
    @Override
    public String toString()
    {
        String result = "";
        for(int i = 0; i < this.currentSize; i++)
        {
            result += members[i].toString() + "\n";
        }
        return result;
    }
    
    /**
     * <pre>
     * Compares this and other ClubZed.
     * Criterias:
     * 1) this.members.length = other.members.length
     * 2) this.currentSize = other.currentSize
     * 3) Each ZigNag inside this and other ClubZed is equal.
     * </pre>
     * @param other another ClubZed.
     * @return true/false
     */
    public boolean equals(ClubZed other)
    {
        boolean equal = true;
        if(this.size() == other.size() && this.capacity() == other.capacity())
        {
            for (int i = 0; i < currentSize; i++)
            {
                equal = this.members[i].equals(other.members[i]);
                if(!equal) break;
            }
        }
        return equal;
    }
    
    /**
     * Returns the number of happy ZigNags inside this ClubZed.
     * @return number of happy ZigNags
     */
    public int countHappyMembers()
    {
        int total = 0;
        for(int i = 0; i < currentSize; i++)
        {
            if(members[i].isHappy()) 
            {
                total++;
            }
        }
        return total;
    }
    
    /**
     * Returns the number of unhappy ZigNags inside this ClubZed.
     * @return number of unhappy ZigNags
     */
    public int countUnhappyMembers()
    {
        int total = 0;
        for(int i = 0; i < currentSize; i++)
        {
            if(members[i].isUnhappy()) 
            {
                total++;
            }
        }
        return total;
    }
    
    /**
     * Returns the number of male ZigNags inside this ClubZed.
     * @return number of male ZigNags
     */
    public int countMaleMembers()
    {
        int total = 0;
        for(int i = 0; i < currentSize; i++)
        {
            if(members[i].isMale()) 
            {
                total++;
            }
        }
        return total;
    }
    
    /**
     * Returns the number of female ZigNags inside this ClubZed.
     * @return number of female ZigNags
     */
    public int countFemaleMembers()
    {
        int total = 0;
        for(int i = 0; i < currentSize; i++)
        {
            if(members[i].isFemale()) 
            {
                total++;
            }
        }
        return total;
    }
    
    /**
     * <pre>
     * Draws the ZigNag at provided index.
     * Throws IndexOutOfBoundsException if index is less than 0 or more then currentSize.
     * </pre>
     * @param index a positive integer (0 included)
     */
    public void draw(int index)
    {
        if(index >= 0 && index < this.currentSize)
        {
            this.members[index].draw();
        }
        else
        {
            throw new IndexOutOfBoundsException("No ZigNags here!");
        }
    }
    
    /**
     * Doubles the size of this ClubZed.
     */
    public void resize()
    {
        ZigNag[] doubleCopy = new ZigNag[this.members.length * 2];
        System.arraycopy(this.members, 0, doubleCopy, 0, this.currentSize);
        this.members = doubleCopy;
    }
    
    /**
     * <pre>
     * Adds a newly created ZigNag member to this ClubZed.
     * Resizes this ClubZed array if it isFull().
     * New ZigNag parameters:
     * 1) Gender and mood - set at random.
     * 2) Age is between 3 and 10 inclusive.
     * 3) Character can be either a digit, a uppercase/lowercase letter or
     * one of these symbols: '!', '@', '$', '%', '.', '&', '*', '+', '-', '/'
     * or '=', selected randomly.
     * </pre>
     */
    public void populate()
    {
        if(this.isFull())
        {
            this.resize();
        }
        ZigNag newMember = new ZigNag(RAND.nextBoolean(), RAND.nextBoolean(), pickChar());
        newMember.setAge(RAND.nextInt(8) + 3);
        this.members[currentSize] = newMember;
        this.currentSize++;
    }
    
    /**
     * <pre>
     * Adds a newly created ZigNag to this ClubZed n times.
     * Delegates its work to populate() method.
     * </pre>
     * @param n a positive integer.
     */
    public void populate(int n)
    {
        if(n < 0)
        {
            throw new IllegalArgumentException("Negative times? What?");
        }
        for(int i = 0; i < n; i++)
        {
           this.populate();
        }
    }
    
    /**
     * <pre>
     * Adds an existing ZigNag to this ClubZed.
     * The ZigNag must correspond to the criterias listed in populate() method.
     * </pre>
     * @param joiner the joining ZigNag
     */
    public void join(ZigNag joiner)
    {
        if(joiner.getAge() > 2 && joiner.getAge() < 11)
        {
            if(symbolCheck(joiner.getSymbol()))
            {
                if(this.isFull())
                {
                    this.resize();
                }
                this.members[currentSize] = joiner;
                this.currentSize++;
            }
            else
            {
                throw new IllegalArgumentException("Invalid symbol detected");
            }
        }
        else
        {
            throw new IllegalArgumentException("Invalid age to join the club");
        }
    }
    
    /**
     * Computes the histogram of ages of the members of this ClubZed.
     * @return array of frequencies
     */
    public int[] computeAgeFrequency()
    {
        int[] array = new int[11];
        for(int i = 0; i < 11; i++)
        {
            for(int k = 0; k < this.currentSize; k++)
            {
                if(this.members[k].getAge() == i)
                {
                    array[i]++;
                }
            }
        }
        return array;
    }
    
    /*
    Checks if the symbol of joining ZigNag conforms to criteria #3,
    scrolling through each valid character.
    */
    private static boolean symbolCheck(char symbol)
    {
        boolean check = false;
        for(int i = 0; i < ALPHABET.length(); i++)
        {
            check = (symbol == ALPHABET.charAt(i));
            if(check) break;
        }
        return check;
    }

    /*
    Picks a valid character randomly.
    */
    private static char pickChar()
    {
        char symbol = ALPHABET.charAt(RAND.nextInt(ALPHABET.length()));
        return symbol;
    }
}
