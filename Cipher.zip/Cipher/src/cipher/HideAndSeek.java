/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cipher;

/**
 *
 * @author cstuser
 */
public interface HideAndSeek
{
    //returns encrypted version of message as a ciphertext String
    public String cipher(String message);
    
    //returns decrypted version of message as a plaintext String
    public String decipher(String message);
}
