/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cipher;

/**
 *
 * @author cstuser
 */
public class ShuffleCipher implements HideAndSeek
{
    @Override
    public String cipher(String message)
    {
        char[] chars = new char[message.length()];
        int mid = message.length()/2;
        for(int k = 0; k < message.length(); ++k)
        {
            if(k%2 == 0)
                chars[k] = message.charAt(mid + k/2);
            else
                chars[k] = message.charAt(k/2);
        }
        StringBuilder ciphered = new StringBuilder();
        return ciphered.append(chars).toString();
    }
    
    @Override
    public String decipher(String message)
    {
        char[] chars = new char[message.length()];
        int mid = message.length()/2;
        for(int k = 0; k < message.length(); ++k)
        {
            if(k%2 == 0)
                chars[k] = message.charAt(mid + k/2);
            else
                chars[k] = message.charAt(k/2);
        }
        StringBuilder deciphered = new StringBuilder();
        return deciphered.append(chars).toString();
    }
}
