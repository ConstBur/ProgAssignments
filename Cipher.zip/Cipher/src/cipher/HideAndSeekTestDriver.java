/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cipher;

/**
 *
 * @author cstuser
 */
public class HideAndSeekTestDriver 
{
    private static int reverseCipherSize = 3;
    //demonstrates Polymorphism through variables of an interface,
    //namely, HideAndSeek
    public static void testInterfacePolymorphism(HideAndSeek hs, String message)
    {
        //hs references any object that implements the HideAndSeek interface
        System.out.printf("%15s  %s  length: %d%n", "who am I?",
                hs.getClass().getName(), message.length());
        
        System.out.printf("%15s: %s%n", "from plaintext", message);
        
        String encryptedMessage = hs.cipher(message);
        System.out.printf("%15s: %s%n", "to ciphertext", encryptedMessage);
        
        String decryptedMessage = hs.decipher(encryptedMessage);
        System.out.printf("%15s: %s%n", "and back again", decryptedMessage);
    }
    
    public static void main(String[] args) 
    {
        String message = "you love Parish";
        
        ReverseCipher rc = new ReverseCipher(reverseCipherSize);
        testInterfacePolymorphism(rc, message);
        System.out.println();
        
        ShuffleCipher sc = new ShuffleCipher();
        
        testInterfacePolymorphism(sc, message);
        System.out.println();
    }
}
