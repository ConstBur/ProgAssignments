/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cipher;

import java.util.Arrays;

/**
 *
 * @author cstuser
 */
public class ReverseCipher implements HideAndSeek
{
    private int key;
    
    public ReverseCipher(int key)
    {
        this.key = key;
    }
    
    @Override
    public String cipher(String message)
    {
        int piecesNum = 0;
        String[] pieces = new String[message.length()/key + 1];
        for(int i = 0; i < message.length(); i+=key)
        {
            String plaintext = message.substring(i, i+key);
            String ciphered = reverse(plaintext, i, i+key);
            pieces[piecesNum] = ciphered;
            ++piecesNum;
        }
        StringBuilder sb = new StringBuilder();
        for (String piece : pieces) 
        {
            sb.append(piece);
        }
        return sb.toString();
    }
    
    @Override
    public String decipher(String message)
    {
        int piecesNum = 0;
        String[] pieces = new String[message.length()/key + 1];
        for(int i = 0; i < message.length(); i+=key)
        {
            String ciphered = message.substring(i, i+key);
            String plaintext = reverse(ciphered, i, i+key);
            pieces[piecesNum] = plaintext;
            ++piecesNum;
        }
        StringBuilder sb = new StringBuilder();
        for (String piece : pieces) 
        {
            sb.append(piece);
        }
        return sb.toString();
    }
    
    private static String reverse(String str, int left, int right)
    {
        String reversed = "";
        if(left < right)
        {
            char[] chars = str.toCharArray();
            char temp = chars[left];
            chars[left] = chars[right];
            chars[right] = temp;
            StringBuilder reverse = new StringBuilder();
            reverse.append(chars);
            reverse(reverse.toString(), left+1, right-1);
            reversed = reverse.toString();
        }
        return reversed;
    }
}
