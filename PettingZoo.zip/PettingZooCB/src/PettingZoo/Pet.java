package PettingZoo;
/**
 *
 * @author constbur
 */
abstract public class Pet
{
    private final String name;
    private int age;
    private final char gender;
    
    /**
     * <pre>
     * Creates a Pet object with provided name.
     * Age is set to 1 and gender is set at random.
     * </pre>
     * @param name any name
     * @param age any integer
     * @param gender M or F
     */
    public Pet(String name, int age, char gender)
    {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
    
    /**
     * Returns the name of this Pet.
     * @return this.name
     */
    public String getName()
    {
        return this.name;
    }
    
    /**
     * Returns the age of this Pet.
     * @return this.age
     */
    public int getAge()
    {
        return this.age;
    }
    
    /**
     * Returns the gender of this Pet.
     * @return this.gender
     */
    public char getGender()
    {
        return this.gender;
    }
    
    /**
     * Increments the age of this Pet by 1.
     */
    public void growup()
    {
        this.age++;
    }
    
    /**
     * Prints the info about this Pet.
     * @return String representation of this Pet
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("I'm ");
        sb.append(this.name);
        sb.append(", a ");
        sb.append(this.age);
        sb.append("-year old ");
        sb.append(this.gender == 'M' ? "male " : "female ");
        sb.append("pet ");
        return sb.toString();
    }
    
    /**
     * Compares this and other Pet based on age, gender and name.
     * @param other another Pet object
     * @return true if every property is the same
     */
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Pet)
        {
            Pet pet = (Pet)other;
            return(this.age == pet.age && this.gender == pet.gender
                && this.name.equals(pet.name));
        }
        else return false;
    }
    
    /**
     * Prints a friendly message from this Pet.
     */
    public void talk()
    {
        System.out.print("Hi there, this is " + this.name + " talking: ");
    }
    
    /**
     * An abstract method that should return the Pet scream.
     * @return Pet scream
     */
    abstract public String speak();
}
