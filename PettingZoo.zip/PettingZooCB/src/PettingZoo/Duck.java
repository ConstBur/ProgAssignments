package PettingZoo;

/**
 *
 * @author constbur
 */
public class Duck extends Pet
{
    private int eggs;
    
    /**
     * Creates a Duck with provided properties.
     * @param name any String
     * @param age an integer
     * @param gender 'M' or 'F', defined at random
     * @param eggs an integer
     */
    public Duck(String name, int age, char gender, int eggs)
    {
        super(name, age, gender);
        this.eggs = eggs;
    }
    
    /**
     * Adds an egg for this Duck.
     */
    public void layAnEgg()
    {
        this.eggs++;
    }
    
    /**
     * Simulates swimming.
     */
    public void swim()
    {
        System.out.println(this.getName() + " is swimming ...");
    }
    
    /**
     * Returns the number of eggs for this Duck.
     * @return this.eggs
     */
    public int getEggs()
    {
        return this.eggs;
    }
    
    /**
     * Simulates flying.
     */
    public void fly()
    {
        System.out.println(this.getName() + " is flying ...");
    }
    
    /**
     * Creates the String representation of this Duck.
     * @return Duck info
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("duck with ");
        sb.append(this.getEggs());
        sb.append(" eggs");
        return sb.toString();
    }
    
    /**
     * Compares this Duck with an Object.
     * @param other an Object
     * @return false if Object doesn't exist, isn't a Duck, or has different properties
     */
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Duck)
        {
            Duck duck = (Duck)other;
            return super.equals(duck) && this.getEggs() == duck.getEggs();
        }
        else return false;
    }
    
    /**
     * Makes this Duck talk!
     */
    @Override
    public void talk()
    {
        super.talk();
        System.out.println("Quack-Quack-Quack!");
    }
    
    /**
     * Returns the Duck scream.
     * @return "quack!"
     */
    @Override
    public String speak()
    {
        return "quack!";
    }
}
