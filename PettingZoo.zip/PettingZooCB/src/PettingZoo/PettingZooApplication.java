package PettingZoo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class PettingZooApplication
{
    public static final String BEGIN_DASHES = "================";
    public static final String END_DASHES = "====================";
    
    public static String zooDashes(String zoo)
    {
        StringBuilder dashes = new StringBuilder();
        for(int i = 0; i < zoo.length(); i++)
        {
            dashes.append("=");
        }
        return dashes.toString();
    }
    
   public static void main(String[] args) throws IOException
   {
      PettingZoo cavendishZoo = new PettingZoo("Quartier Cavendish Petting Zoo");
      System.out.println("Created the " + cavendishZoo.getName());
      System.out.println(cavendishZoo);
      
      cavendishZoo.addPetInCSVformat("dog, Fido, 5, male, small");
      cavendishZoo.addPetInCSVformat("cat, Garfield, 3, female, true");
      cavendishZoo.addPetInCSVformat("duck, Donald, 7, female, 9");
      
      System.out.print(cavendishZoo);
      
      cavendishZoo.growOlder(1);
      System.out.print(cavendishZoo);

      PettingZoo granbyZoo = new PettingZoo("Granby Zoo", "./pet_data.txt");
      System.out.print(granbyZoo);

      StringBuilder dashBuilder = new StringBuilder();
      for (int k = 0; k < ("Summary Report for " + granbyZoo.getName()).length() + 6; ++k)
      {
         dashBuilder.append("-");
      }
      String dashes = dashBuilder.toString();
      System.out.println(dashes);
      System.out.println("Summary Report for " + granbyZoo.getName());
      System.out.println(dashes);
      System.out.println("Number of types of pets: " + granbyZoo.howManyPetTypes());
      System.out.println("Number of pets         : " + granbyZoo.howManyPets());
      System.out.println("Number of male pets    : " + granbyZoo.howManyMalePets());
      System.out.println("Number of female pets  : " + granbyZoo.howManyFemalePets());
      System.out.println("Number of pet dogs     : " + granbyZoo.howMany("dog"));
      System.out.println("Number of pet cats     : " + granbyZoo.howMany("cat"));
      System.out.println("Number of pet ducks    : " + granbyZoo.howMany("duck"));
      System.out.println(dashes);

      ArrayList<Pet> retiredPetList = granbyZoo.retire(5); // retire pets older that
      System.out.println("\nList of retired pets:");
      for (int k = 0; k < retiredPetList.size(); ++k)
      {
         System.out.printf("%2d %s (%s)\n", k + 1, retiredPetList.get(k),
                 retiredPetList.get(k).speak());
      }
      System.out.println("End list of retired pets\n");

      System.out.print(granbyZoo); // print current pets in the zoo

      Scanner sc = new Scanner(System.in);
      System.out.println("Writing " + granbyZoo.getName() + " to a file...");
      System.out.println("Which file name would you like to choose (without .txt)?");
      String outputFileName = "./" + sc.nextLine() + ".txt"; // allows user to specify file name
      granbyZoo.outputCSV(outputFileName);// write pet list to outputFileName
      System.out.println("Data was written successfully!");
      System.out.println("Find the file inside the project folder.");
      sc.close();
      return;
   }
}
