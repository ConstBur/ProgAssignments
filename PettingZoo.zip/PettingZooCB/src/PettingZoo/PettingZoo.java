package PettingZoo;

import java.io.*;
import java.util.*;

/**
 * Programmer: Constantin Buruiana
 * Date: April 5, 2018
 * Purpose: Create a zoo of pets using ArrayLists and practice writing to a file.
 * @author Constantin Buruiana
 */
public class PettingZoo
{
    private String name;
    private ArrayList<Pet> petList;
    private ArrayList<String> petTypes;
    
    /**
     * Creates an empty PettingZoo with the provided zooName.
     * @param zooName any String
     */
    public PettingZoo(String zooName)
    {
        this.name = zooName;
        this.petList = new ArrayList<>();
        this.petTypes = new ArrayList<>();
    }
    
    /**
     * Creates a PrttingZoo from csvPetFile with provided zooName.
     * @param zooName any String
     * @param csvPetFile a String representing a path to existing file containing pets in CSV format
     * @throws FileNotFoundException in case there is no file at csvPetFile
     */
    public PettingZoo(String zooName, String csvPetFile) throws FileNotFoundException
    {
        this(zooName);
        this.loadPetListFromCSVfile(csvPetFile);
    }
    
    /*
    Scans the Pets from csvPetFile and delegates its work to addPetToCSVformat method.
    Throws FileNotFoundException if the csvPetFile doesn't exist.
    */
    private void loadPetListFromCSVfile(String csvPetFile) throws FileNotFoundException
    {
        File inputFile = new File(csvPetFile);
        if(!inputFile.exists())
        {
            throw new FileNotFoundException("Cannot open " + csvPetFile + 
                    "\nThe list of pets in the zoo remains unchanged!");
        }
        Scanner sc = new Scanner(inputFile);
        while(sc.hasNextLine())
        {
            String csvLine = sc.nextLine();
            addPetInCSVformat(csvLine);
        }
    }
    
    /**
     * Parses the records in CSV file and creates Pets from it, sending those to petList and petTypes.
     * @param csvPetRecord a line from CSV file
     */
    public void addPetInCSVformat(String csvPetRecord)
    {
        csvPetRecord = csvPetRecord.trim();
        //Separating values in each record
        String[] values = csvPetRecord.split("\\s*,\\s*");
        String petType = values[0].trim().toLowerCase();
        String petName = values[1].trim();
        int petAge = Integer.parseInt(values[2].trim());
        char petGender = values[3].trim().toUpperCase().charAt(0);
        String property = values[4].trim();
        //Creating a placeholder for a Pet
        Pet pet = null;
        //Creating Pet objects depending on pet type
        switch(petType)
        {
            case "dog":
            {
                pet = new Dog(petName, petAge, petGender, property);
                break;
            }
            case "cat":
            {
                boolean neutered = Boolean.parseBoolean(property);
                pet = new Cat(petName, petAge, petGender, neutered);
                break;
            }
            case "duck":
            {
                int eggs = Integer.parseInt(property);
                pet = new Duck(petName, petAge, petGender, eggs);
                break;
            }
        }
        //Adding pets to the lists
        this.petList.add(pet);
        this.petTypes.add(petType);
    }
    
    /**
     * Prints the name of this PettingZoo.
     * @return this.name
     */
    public String getName()
    {
        return this.name;
    }
    
    /**
     * Sets the name of this PettingZoo to the provided String.
     * @param name any String
     */
    public void setName(String name)
    {
        this.name = name;
    }
    
    /**
     * Checks how many types of Pets are in petTypes.
     * @return 0-3
     */
    public int howManyPetTypes()
    {
        if(this.petTypes.isEmpty())
            return 0;
        else if(this.petTypes.contains("dog") && this.petTypes.contains("cat") && this.petTypes.contains("duck"))
            return 3;
        else if(this.petTypes.contains("dog") && this.petTypes.contains("cat") ||
                this.petTypes.contains("dog") && this.petTypes.contains("duck") ||
                this.petTypes.contains("cat") && this.petTypes.contains("duck"))
            return 2;
        else return 1;
    }
    
    /**
     * Counts the number of Pets of a given petType.
     * @param petType a String containing a pet type
     * @return the number of Pets of a given type
     */
    public int howMany(String petType)
    {
        int counter = 0;
        petType = petType.toLowerCase();
        if(!this.petTypes.contains(petType))
            return 0;
        for (Pet pet: this.petList)
        {
            if(pet == null)
                break;
            switch(petType)
            {
                case "dog":
                    if(pet instanceof Dog) ++counter;
                    break;
                case "cat":
                    if(pet instanceof Cat) ++counter;
                    break;
                case "duck":
                    if(pet instanceof Duck) ++counter;
                    break;
            }
        }
        return counter;
    }
    
    /**
     * Returns the size of the PettingZoo.
     * @return petList.size()
     */
    public int howManyPets()
    {
        return this.petList.size();
    }
    
    /**
     * Counts male Pets inside this petList.
     * @return number of male Pets
     */
    public int howManyMalePets()
    {
        int counter = 0;
        for (Pet pet : this.petList)
        {
            if(pet == null)
                break;
            if(pet.getGender() == 'M')
                ++counter;
        }
        return counter;
    }
    
    /**
     * Counts female Pets inside this petList.
     * @return number of female Pets
     */
    public int howManyFemalePets()
    {
        int counter = 0;
        for (Pet pet : this.petList)
        {
            if(pet == null)
                break;
            if(pet.getGender() == 'F')
                ++counter;
        }
        return counter;
    }
    
    /**
     * Increments the age of each Pet in this petList by n.
     * @param n a positive integer
     */
    public void growOlder(int n)
    {
        if(n <= 0)
        {
            System.out.println("Animals can't grow up backwards...");
            return;
        }
        for(Pet pet : this.petList)
        {
            if(pet == null)
                break;
            for (int i = 0; i < n; i++)
            {
                pet.growup();
            }   
        }
    }
    
    /**
     * Eliminates Pets that are older than the given age.
     * @param age an integer
     * @return the ArrayList of retired Pets
     */
    public ArrayList<Pet> retire(int age)
    {
        ArrayList<Pet> retired = new ArrayList<>();
        for(Pet pet : this.petList)
        {
            if(pet == null)
                break;
            if(pet.getAge() >= age)
                retired.add(pet);
        }
        this.petList.removeAll(retired);
        return retired;
    }
    
    /**
     * Writes the Pets inside this PettingZoo to the file at fileName.
     * @param fileName a String containing path to the output file
     * @throws IOException in case if the file could not be opened for writing
     */
    public void outputCSV(String fileName) throws IOException
    {
        FileWriter fw = new FileWriter(fileName);
        StringBuilder sb = new StringBuilder();
        for(Pet pet : this.petList)
        {
            if(pet == null)
                break;
            //Using Pet's toString() to get info
            String currentPet = pet.toString();
            Scanner sc = new Scanner(currentPet);
            //Using just sc.next() skips unneccessary parts
            sc.next();
            StringBuilder petName = new StringBuilder();
            do
            {
                petName.append(sc.next()).append(" ");
            } while(petName.indexOf(",") == -1);
            sc.next();
            char age = sc.next().charAt(0);
            sc.next();
            String gender = sc.next();
            sc.next();
            String type = sc.next();
            type = (type.contains(",") ? type + " " : "duck, ");
            sc.next();
            String property = "";
            switch(type)
            {
                case "dog, ":
                    property = sc.next();
                    break;
                case "cat, ":
                    property = sc.next().equals("neutered") ? "true" : "false";
                    break;
                case "duck, ":
                    property = sc.next();
                    break;
            }
            sb.append(type);
            sb.append(petName);
            sb.append(age).append(", ");
            sb.append(gender).append(", ");
            sb.append(property).append("\n");
            sc.close();
        }
        fw.write(sb.toString());
        fw.close();
    }
    
    /**
     * Creates a String representation of each Pet inside this PettingZoo.
     * @return PettingZoo info
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        if(this.petList.isEmpty())
        {
            sb.append("\nThe ").append(this.getName()).append(" is empty\n");
        }
        else
        {
            int longest = 3, counter = 0; 
            for(Pet pet : this.petList)
            {
                if(pet.toString().length() > longest)
                    longest = pet.toString().length();
            }
            for (int i = 0; i < longest; i++) 
            {
                sb.append("=");                    
            }
            sb.append("\nList of pets at ").append(this.getName()).append("\n");
            for (int i = 0; i < longest; i++) 
            {
                sb.append(".");                    
            }
            sb.append("\n");
            for(Pet pet : this.petList)
            {
                sb.append(++counter).append("  ").append(pet.toString()).append("\n");
            }
            for (int i = 0; i < longest; i++) 
            {
                sb.append("=");                    
            }
            sb.append("\n");
        }
        return sb.toString();
    }
    
    /**
     * Compares PettingZoo to an Object.
     * @param other an Object
     * @return false if Object doesn't exist, isn't a PettingZoo, isn't of the same size or has different number of Pets of each kind.
     */
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof PettingZoo)
        {
            PettingZoo zoo = (PettingZoo)other;
            if(this.petTypes.size() != zoo.petTypes.size())
                return false;
            int thisDogs = 0, thisCats = 0, thisDucks = 0;
            for(Pet pet: this.petList)
            {
                if(pet == null)
                    break;
                else if(pet instanceof Dog)
                    ++thisDogs;
                else if(pet instanceof Cat)
                    ++thisCats;
                else ++thisDucks;
            }
            int otherDogs = 0, otherCats = 0, otherDucks = 0;
            for(Pet pet: zoo.petList)
            {
                if(pet == null)
                    break;
                else if(pet instanceof Dog)
                    ++otherDogs;
                else if(pet instanceof Cat)
                    ++otherCats;
                else ++otherDucks;
            }
            return thisDogs == otherDogs && thisCats == otherCats && thisDucks == otherDucks;
        }
        return false;
    }
}
