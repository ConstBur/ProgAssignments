package PettingZoo;
/**
 *
 * @author constbur
 */
public class Dog extends Pet
{
    private final String size;
    
    /**
     * Creates a Dog with provided parameters.
     * @param name any String
     * @param age an integer
     * @param gender 'M' or 'F', determined at random
     * @param size any String
     */
    public Dog(String name, int age, char gender, String size)
    {
        super(name, age, gender);
        this.size = size;
    }
    
    /**
     * Returns the size of this Doge.
     * @return this.size
     */
    public String getSize()
    {
        return this.size;
    }
    
    /**
     * Simulates dog panting.
     */
    public void pant()
    {
        System.out.println(this.getName() + " is panting as usual ...");
    }
    
    /**
     * Simulates guarding home.
     */
    public void guardHome()
    {
        System.out.println(this.getName() + " is guarding home ...");
    }
    
    /**
     * Creates a String representation of this Doge.
     * @return Doge info
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("dog, a ");
        sb.append(this.size);
        sb.append(" dog");
        return sb.toString();
    }
    
    /**
     * Compares this Cat to an Object.
     * @param other an Object
     * @return false if the object does not exist, isn't a Cat or has different properties.
     */
    @Override
    public boolean equals(Object other)
    {
        if(other instanceof Dog)
        {
            Dog dog = (Dog)other; //int result = (int)Math.pow(2,3);
            return super.equals(dog) && this.size.equals(dog.size);
        }
        else return false;
    }
    
    /*public boolean equals(Dog other)
    {
        return super.equals(other) && this.size.equals(other.size);
    }*/
    
    /**
     * Makes this Doge talk!
     */
    @Override
    public void talk()
    {
        super.talk();
        System.out.println("Woof-Woof-Woof!");
    }
    
    /**
     * Returns the Doge scream.
     * @return "woof!"
     */
    @Override
    public String speak()
    {
        return "woof!";
    }
}
