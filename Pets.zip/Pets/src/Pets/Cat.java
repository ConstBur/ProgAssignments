/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pets;
/**
 * Subclass of Pet.
 * @author constbur
 */
public class Cat extends Pet
{
    private final boolean neutered;
    
    /**
     * Creates a Cat object using Pet constructor.
     * @param name any name
     * @param neutered true/false
     */
    public Cat(String name, boolean neutered)
    {
        super(name);
        this.neutered = neutered;
    }
    
    /**
     * Checks if this Cat is neutered.
     * @return true if this Cat is neutered.
     */
    public boolean isNeutered()
    {
        return this.neutered;
    }
    
    /**
     * Imitates purring of a cat.
     */
    public void purr()
    {
        System.out.println(this.getName() + " is purring ...");
    }
    
    /**
     * Imitates catching mice.
     */
    public void catchMice()
    {
        System.out.println(this.getName() + " is catching mice ...");
    }
    
    /**
     * Prints the info about this Cat.
     * @return String representation of this Cat
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("cat, a ");
        sb.append(this.isNeutered() == true ? "neutered " : "non-neutered ");
        sb.append("cat");
        return sb.toString();
    }
    
    /**
     * <pre>
     * Compares this Cat with an Object.
     * If the passed Object is null or isn't a Cat - returns false.
     * </pre>
     * @param other an Object
     * @return true if every parameter is equal
     */
    @Override
    public boolean equals(Object other)
    {
        if(other == null || !(other instanceof Cat))
            return false;
        Cat cat = (Cat) other;
        return super.equals(other) && this.isNeutered() == cat.isNeutered();
    }     
    
    /**
     * Makes this Cat talk!
     */
    @Override
    public void talk()
    {
        super.talk();
        System.out.println("Meow-Meow-Meow!");
    }
}
