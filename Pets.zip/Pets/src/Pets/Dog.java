/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pets;
/**
 * Subclass of Pet.
 * @author constbur
 */
public class Dog extends Pet
{
    private final String size;
    
    /**
     * Creates a Dog object using Pet constructor.
     * @param name any String
     * @param size any String
     */
    public Dog(String name, String size)
    {
        super(name);
        this.size = size;
    }
    
    /**
     * Returns the size of this Dog.
     * @return this.size
     */
    public String getSize()
    {
        return this.size;
    }
    
    /**
     * Simulates Dog panting.
     */
    public void pant()
    {
        System.out.println(this.getName() + " is panting as usual ...");
    }
    
    /**
     * Simulates Dog guarding home.
     */
    public void guardHome()
    {
        System.out.println(this.getName() + " is guarding home ...");
    }
    
    /**
     * Prints out the info about this Dog.
     * @return String representation of this Dog
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("dog, a ");
        sb.append(this.size);
        sb.append(" dog");
        return sb.toString();
    }
    
    /**
     * <pre>
     * Compares this Dog with an Object.
     * If the passed Object is null or isn't a Dog - returns false.
     * </pre>
     * @param other an Object
     * @return true if every parameter is equal
     */
    @Override
    public boolean equals(Object other)
    {
        if(other == null || !(other instanceof Dog))
            return false;
        Dog dog = (Dog)other;
        return super.equals(other) && this.size.equals(dog.size);
    }
    
    /**
     * Makes this Dog talk!
     */
    @Override
    public void talk()
    {
        super.talk();
        System.out.println("Woof-Woof-Woof!");
    }
}
