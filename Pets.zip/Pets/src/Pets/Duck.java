/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pets;

/**
 * Subclass of Pet.
 * @author constbur
 */
public class Duck extends Pet
{
    private int eggs;
    
    /**
     * Creates a Duck using Pet constructor.
     * @param name any String
     */
    public Duck(String name)
    {
        super(name);
        this.eggs = 0;
    }
    
    /**
     * Increments the number of eggs by 1.
     */
    public void layAnEgg()
    {
        this.eggs++;
    }
    
    /**
     * Simulates this Duck swimming.
     */
    public void swim()
    {
        System.out.println(this.getName() + " is swimming ...");
    }
    
    /**
     * Returns the number of eggs of this Duck.
     * @return this.eggs
     */
    public int getEggs()
    {
        return this.eggs;
    }
    
    /**
     * Simulates this Duck flying.
     */
    public void fly()
    {
        System.out.println(this.getName() + " is flying ...");
    }
    
    /**
     * Prints out the info about this Duck.
     * @return String representation of this Duck
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("duck with ");
        sb.append(this.getEggs());
        sb.append(" eggs");
        return sb.toString();
    }
    
    /**
     * <pre>
     * Compares this Duck with an Object.
     * If the passed Object is null or isn't a Duck - returns false.
     * </pre>
     * @param other an Object
     * @return true if every parameter is equal
     */
    @Override
    public boolean equals(Object other)
    {
        if(other == null || !(other instanceof Duck))
            return false;
        Duck duck = (Duck)other;
        return super.equals(other) && this.getEggs() == duck.getEggs();
    }
    
    /**
     * Makes this Duck talk!
     */
    @Override
    public void talk()
    {
        super.talk();
        System.out.println("Quack-Quack-Quack!");
    }
}
