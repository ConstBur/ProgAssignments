/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pets;

/**
 * Test driver for the Pet and its subclasses.
 * @author constbur
 */
public class PetTestDriver 
{
    public static void main(String[] args)
    {
        Dog fido = new Dog("Fido", "medium"); // age is 1, gender is random
        System.out.println(fido);
        fido.growup();
        System.out.println(fido);
        fido.growup();
        System.out.println(fido);
        fido.growup();
        System.out.println(fido);
        fido.guardHome();
        fido.pant();
        
        boolean spayed = true;
        Cat garfield = new Cat("Garfield", spayed); // age is 1, gender is random
        garfield.growup();
        System.out.println(garfield);
        garfield.catchMice();
        garfield.purr();
        
        Duck daffy = new Duck("Daffy"); // age is 1, gender is random
        System.out.println(daffy);
        daffy.growup();
        System.out.println(daffy);
        daffy.growup();
        System.out.println(daffy);
        daffy.layAnEgg();
        System.out.println(daffy);
        daffy.layAnEgg();
        System.out.println(daffy);
        daffy.swim();
        daffy.fly();
        
        // Practice Polymorphism
        Pet p1 = new Dog("Oscar", "large");
        p1.talk(); // at run-time our pet dog Oscar will talk!
        
        p1 = garfield;
        p1.talk(); // at run-time out pet cat Garfield will talk!
        
        Pet p2 = new Duck("Donald");
        p2.talk(); // at run-time our pet duck Donald will talk!
    }
}
