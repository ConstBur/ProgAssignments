/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pets;
import java.util.Random;
/**
 * <pre>
 * Programmer: Constantin Buruiana
 * Date: March 8, 2018
 * Purpose: Simulate some Pets using subclasses.
 * </pre>
 * @author constbur
 */
public class Pet extends Object
{
    private final String name;
    private int age;
    private final char gender;
    private static final Random RAND = new Random();
    
    /**
     * <pre>
     * Creates a Pet object with provided name.
     * Age is set to 1 and gender is set at random.
     * </pre>
     * @param name any name
     */
    public Pet(String name)
    {
        this.name = name;
        this.age = 1;
        this.gender = (RAND.nextBoolean() == true ? 'M' : 'F');
    }
    
    /**
     * Returns the name of this Pet.
     * @return this.name
     */
    public String getName()
    {
        return this.name;
    }
    
    /**
     * Returns the age of this Pet.
     * @return this.age
     */
    public int getAge()
    {
        return this.age;
    }
    
    /**
     * Returns the gender of this Pet.
     * @return this.gender
     */
    public char getGender()
    {
        return this.gender;
    }
    
    /**
     * Increments the age of this Pet by 1.
     */
    public void growup()
    {
        this.age++;
    }
    
    /**
     * Prints the info about this Pet.
     * @return String representation of this Pet
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("I'm ");
        sb.append(this.name);
        sb.append(", a ");
        sb.append(this.age);
        sb.append("-year old ");
        sb.append(this.gender == 'M' ? "male " : "female ");
        sb.append("pet ");
        return sb.toString();
    }
    
    /**
     * <pre>
     * Compares this Pet with an Object.
     * If the passed Object is null or isn't a Pet - returns false.
     * </pre>
     * @param other an Object
     * @return true if every parameter is equal
     */
    @Override
    public boolean equals(Object other)
    {
        if(other == null || !(other instanceof Pet))
            return false;
        Pet pet = (Pet)other;
        return(this.age == pet.age && this.gender == pet.gender
                && this.name.equals(pet.name));
    }
    
    /**
     * Makes this Pet talk!
     */
    public void talk()
    {
        System.out.print("Hi there, this is " + this.name + " talking: ");
    }
}
