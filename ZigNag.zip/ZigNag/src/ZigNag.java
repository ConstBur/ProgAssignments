
import java.util.Random;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * <pre>
 * Programmer: Constantin Buruiana
 * Date: January 31st, 2018
 * Purpose: Previous semester review + first attempt at Javadocs.
 * </pre>
 * @author Constantin Buruiana
 */
public class ZigNag extends Object 
{
    
    //ZigNag properties' variables declaration
    private int age;
    private boolean gender;
    private boolean mood;
    private char symbol;
    
    //Pseudorandom generator
    private static final int SEED = 47;
    private static Random rand = new Random(SEED);
    
    //

    /**
     * <pre>
     * Default constructor.
     * Parameters:
     * age = 1;
     * symbol = '*';
     * gender = true/false (male/female, at random);
     * mood = true/false (happy/unhappy, at random)
     * </pre>
     */
    public ZigNag()
    {
        this.age = 1;
        this.symbol = '*';
        this.gender = rand.nextBoolean();
        this.mood = rand.nextBoolean();
    }
    
    //

    /**
     * <pre>
     * Regular constructor.
     * Age is set to 1 by default.
     * Gender, mood and symbol are provided in the arguments.
     * </pre>
     * @param gender = true/false (male/female)
     * @param mood = true/false (happy/unhappy)
     * @param symbol = any valid symbol
     */
    public ZigNag(boolean gender, boolean mood, char symbol)
    {
        this.age = 1;
        this.gender = gender;
        this.mood = mood;
        this.symbol = symbol;
    }
    
    //

    /**
     * <pre>
     * Copy constructor.
     * Takes another ZigNag object and copies its parameters to this object.
     * </pre>
     * @param zig: another ZigNag object
     */
    public ZigNag(ZigNag zig)
    {
        this(zig.gender, zig.mood, zig.symbol);
        this.age = zig.age;
    }
    
    //Getters (accessors)

    /**
     * Returns age of this object.
     * @return this.age
     */
    public int getAge()
    {
        return this.age;
    }
    
    /**
     * Returns symbol of this object.
     * @return this.symbol
     */
    public char getSymbol()
    {
        return this.symbol;
    }
    
    //Setters (mutators)

    /**
     * Sets the age of this ZigNag to the one provided.
     * @param age: any positive integer
     */
    public void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Sets the gender of this ZigNag to the one provided.
     * @param gender: true/false (male/female)
     */
    public void setGender(boolean gender)
    {
        this.gender = gender;
    }
    
    /**
     * Sets the mood of this ZigNag to the one provided.
     * @param mood: true/false (happy/unhappy)
     */
    public void setMood(boolean mood)
    {
        this.mood = mood;
    }
    
    /**
     * Sets the symbol of this ZigNag to the one provided.
     * @param symbol: any valid symbol
     */
    public void setSymbol(char symbol)
    {
        this.symbol = symbol;
    }
    
    //Gender/mood checking methods

    /**
     * Returns true if the invoking ZigNag is male.
     * @return this.gender == true
     */
    public boolean isMale()
    {
        return (this.gender == true);
    }
    
    /**
     * Returns true if the invoking ZigNag is female.
     * @return this.gender == false
     */
    public boolean isFemale()
    {
        return (this.gender == false);
    }
    
    /**
     * Returns true if the invoking ZigNag is happy.
     * @return this.mood == true
     */
    public boolean isHappy()
    {
        return (this.mood == true);
    }
    
    /**
     * Returns true if the invoking ZigNag is unhappy.
     * @return this.mood == false
     */
    public boolean isUnhappy()
    {
        return (this.mood == false);
    }
    
    //Reversing mood

    /**
     * Inverses the mood of the invoking ZigNag.
     */
    public void reverseMood()
    {
        this.mood = (!this.mood);
    }
    
    //Age comparing

    /**
     * Returns true if the age of this ZigNag is bigger than the other's.
     * @param other: another ZigNag object
     * @return true/false
     */
    public boolean isOlder(ZigNag other)
    {
        return (this.age > other.age);
    }
    
    /**
     * <pre>
     * Returns false if the age of this ZigNag is bigger than the other's.
     * Delegates its work to isOlder function, inverting the result.
     * </pre>
     * @param other: another ZigNag object
     * @return true/false
     */
    public boolean isYounger(ZigNag other)
    {
        return (!this.isOlder(other));
    }

    /**
     * <pre>
     * Checks if the age of invoking ZigNag is between 4 and 6 inclusive.
     * If so, returns true. Else, throws an IllegalArgumentException.
     * </pre>
     * @return true/false
     */
    public boolean canProduce()
    {
        if (this.age > 3 && this.age < 7) return true;
        else throw new IllegalArgumentException("ZigNag can't be produced!");
    }
    
    //Age/gender comparisons

    /**
     * Returns true if this and other ZigNag have the same age.
     * @param other: another ZigNag object.
     * @return this.age == other.age
     */
    public boolean haveSameAge(ZigNag other)
    {
        return (this.age == other.age);
    }
    
    /**
     * Returns true if this and other ZigNag have the same gender.
     * @param other: another ZigNag object.
     * @return this.gender == other.gender
     */
    public boolean haveSameGender(ZigNag other)
    {
        return (this.gender == other.gender);
    }
    
    //Increasing age

    /**
     * <pre>
     * Increments the age of this ZigNag by n.
     * If n is not a positive integer, throws an IllegalArgumentException.
     * </pre>
     * @param n: any positive integer.
     * @throws IllegalArgumentException if n is negative.
     */
    public void growUp(int n) throws IllegalArgumentException
    {
        if (n <= 0)
        {
            throw new IllegalArgumentException("Age is not positive!");
        }
        else this.age += n;
    }
    
    /**
     * Increments the age of this ZigNag by 1.
     * Delegates its work to growUp(int n) function.
     */
    public void growUp()
    {
        this.growUp(1);
    }
    
    //Printing info about a ZigNag

    /**
     * Prints the information about this ZigNag.
     * @return "A (age)-year old (mood) (gender) ZigNag" 
     */
    @Override
    public String toString()
    {
        String result = "";
        result += "A " + this.age + "-year old ";
        result += (this.mood == true ? "happy" : "unhappy");
        result += (this.gender == true ? " male" : " female");
        result += " ZigNag";
        return result;
    }
    
    //ZigNag objects comparison

    /**
     * Returns true if every parameter of this and other ZigNags are the same.
     * @param other: another ZigNag object
     * @return true/false
     */
    public boolean equals(ZigNag other)
    {
        return (this.age == other.age && this.gender == other.gender
                && this.mood == other.mood && this.symbol == other.symbol);
    }
    
    /*
    
    */

    /**
     * <pre>
     * Creating a child ZigNag. Conditions:
     * 1) This and other ZigNags return true from canProduce()
     * 2) They have to be of different genders (this.gender != other.gender)
     * 3) Same mood - passed to child, different moods - defined at random
     * 4) Child gender always defined at random.
     * 5) Age set to 1 by default.
     * 
     * If the conditions are satisfied, returns a ZigNag object.
     * Else, returns null.
     * </pre>
     * @param other: another ZigNag object.
     * @return ZigNag child
     */

    public ZigNag produceZigNag(ZigNag other)
    {
        ZigNag child = new ZigNag();
        if (this.canProduce() && other.canProduce() && 
                this.gender != other.gender)
        {
            child.setGender(rand.nextBoolean());
            if (this.mood == other.mood)
            {
                child.mood = this.mood;
            }
            else
            {
                child.mood = rand.nextBoolean();
            }
        }
        else return null;
        return child;
    }
    
    //
    //(depending on gender and mood)

    /**
     * <pre>
     * Drawing ZigNag method, delegating its work to private methods.
     * Delegation depends on mood and gender:
     * 1) drawN() is called if gender == true and mood == true (male happy)
     * 2) drawInvertedN() is called if gender == true and mood == false (male unhappy)
     * 3) drawZ() is called if gender == false and mood == true (female happy)
     * 4) drawInevertedZ() is called if gender == false and mood == false (female unhappy)
     * Cases when age == 1 or 2 are handled separately.
     * </pre>
     */
    public void draw()
    {
        //Handling cases of age 1 and 2 separately (same for all genders/moods)
        if (this.age == 1)
        {
            System.out.println(this.symbol);
        }
        else if (this.age == 2)
        {
            String result = String.format("%s%s%n%s%s%n", this.symbol,
                    this.symbol, this.symbol, this.symbol);
            System.out.println(result);
        }
        else if (this.isMale() && this.isHappy())
        {
            this.drawN();
        }
        else if (this.isMale() && this.isUnhappy())
        {
            this.drawInvertedN();
        }
        else if (this.isFemale() && this.isHappy())
        {
            this.drawZ();
        }
        else
        {
            this.drawInvertedZ();
        }
    }
    
    //Drawing male happy ZigNag
    private void drawN()
    {
        String result = "";
        
        //String of spaces between characters in first and last rows
        String middle = "%" + this.age + "s";
        
        for (int row = 0; row < this.age; row++)
        {
            //Strings of spaces before and after the middle character
            //(in middle rows)
            String before = "%" + row + "s";
            String after = "%" + (this.age - row - 1) + "s";
            
            //Handling first and last rows separately
            if (row == 0 || row == (this.age - 1))
            {
                result += String.format("%s" + middle + "%s", 
                        this.symbol, " ", this.symbol);
            }
            //Middle rows
            else
            {
                result += String.format("%s" + before + "%s" + after + "%s", 
                        this.symbol, " ", this.symbol, " ", this.symbol);
            }
            result += "\n";
        }
        System.out.println(result);
    }
    
    //Drawing male unhappy ZigNag
    private void drawInvertedN()
    {
        String result = "";
        
        //String of spaces between characters in first and last rows
        String middle = "%" + this.age + "s";
        
        for (int row = 0; row < this.age; row++)
        {
            //Strings of spaces before and after the middle character
            //(in middle rows, inverted order)
            String after = "%" + row + "s";
            String before = "%" + (this.age - row - 1) + "s";
            
            //Handling first and last rows separately
            if (row == 0 || row == (this.age - 1))
            {
                result += String.format("%s" + middle + "%s", 
                        this.symbol, " ", this.symbol);
            }
            //Middle rows
            else
            {
                result += String.format("%s" + before + "%s" + after + "%s", 
                        this.symbol, " ", this.symbol, " ", this.symbol);
            }
            result += "\n";
        }
        System.out.println(result);
    }
    
    //Drawing female happy ZigNag
    private void drawZ()
    {
        String result = "";
        for (int row = 0; row < this.age; row++)
        {
            //String of spaces before character
            //(spaces after don't matter since they're invisible)
            String spaces = "%" + (this.age - row - 1) + "s";
            
            //Handling first amd last rows separately
            if (row == 0 || row == this.age - 1)
            {
                for (int i = 0; i < this.age; i++)
                {
                    result += this.symbol;
                }
            }
            //Middle rows
            else
            {
                result += String.format(spaces + "%s", " ", this.symbol);
            }
            result += "\n";
        }
        System.out.println(result);
    }
    
    //Drawing female unhappy ZigNag
    private void drawInvertedZ()
    {
        String result = "";
        for (int row = 0; row < this.age; row++)
        {
            //String of spaces before character
            //(spaces after don't matter since they're invisible)
            String spaces = "%" + (row + 1) + "s";
            
            //Handling first amd last rows separately
            if (row == 0 || row == this.age - 1)
            {
                for (int i = 0; i < this.age; i++)
                {
                    result += this.symbol;
                }
            }
            //Middle rows
            else
            {
                result += String.format(spaces, this.symbol);
            }
            result += "\n";
        }
        System.out.println(result);
    }
}
