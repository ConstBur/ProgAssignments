package MagicSquare;

/**
 * <pre>
 * Programmer: Constantin Buruiana
 * Date: February 19, 2018
 * Purpose: Make a magic sqaure using 2D arrays.
 * </pre>
 * @author cstuser
 */
public class MagicSquare extends Object
{
    private int order;
    private int[][] square;
    private static final int FIRST = 0;
    private static final int DEFAULT = 3;

    /**
     * Creates a magic square of size 3.
     */
    public MagicSquare()
    {
        this(DEFAULT);
    }

    /**
     * Creates a magic square of a provided size.
     * @param size any integer
     */
    public MagicSquare(int size)
    {
        this.makeMagicSquare(size);
    }

    /**
     * Method creating the magic square of a provided order.
     * @param n any integer
     */
    public final void makeMagicSquare(int n)
    {
        //If the order of the square provided is less than 3 - set to 3.
        if(n < DEFAULT)
        {
            System.out.println("Invalid argument: " + n);
            System.out.println("A default value of " + DEFAULT + " is used instead");
            n = DEFAULT;
        }
        //If the order is even - set to next odd integer.
        else if(n % 2 == 0)
        {
            n++;
        }
        //Setting order to n
        this.order = n;
        //Creating the 2D square array of this order
        this.square = new int[this.order][this.order];

        //Setting initial row to 0 and column to middle
        final int MIDDLE = this.order/2;
        int row = FIRST;
        int col = MIDDLE;
        
        //Filling up the square diagonally with numbers 1...order^2.
        for (int i = 1; i <= this.order*this.order; i++)
        {
            this.square[row][col] = i;
            row--;
            col++;
            final int LAST = this.order - 1;
            /*
            Column and row out-of-bounds check
            If rows and columns are out of bounds at the same time
            or the spot has already been filled -
            increment row by 2 and decrement column.
            */
            if(row < 0 && col >= this.order
                    || this.isInBounds(row, col) && this.square[row][col] != 0)
            {
               row+=2;
               col--;
            }
            //If only row is out of bounds - set to last row.
            else if(row < 0 || row >= this.order)
            {
                row = LAST;
            }
            //If only column is out of bounds - set to the first column.
            else if(col >= this.order)
            {
                col = FIRST;
            }
        }
    }
    
    //Checks if the column and row indexes are in bounds
    private boolean isInBounds(int row, int col)
    {
        return(row >= 0 && row < this.order && col < this.order);
    }

    /**
     * Returns this square side length.
     * @return this.order
     */
    public int getOrder()
    {
        return this.order;
    }

    /**
     * Returns the expected sum of numbers in each row, column and diagonal.
     * @return (this.order^3 + this.order)/2
     */
    public int magicNumber()
    {
        return (int)(Math.pow(this.order, 3) + this.order)/2;
    }

    /**
     * Checks the sum at rows, columns and both diagonals.
     * @return true if passed row, col, mainDig and secDig checks
     */
    public boolean isMagicSquare()
    {
        return (this.rowCheck() && this.colCheck() && this.mainDigCheck()
                && this.secDigCheck());
    }

    /**
     * Checks the sum at each row.
     * @return true if sum == this.magicNumber()
     */
    public boolean rowCheck()
    {
        for (int i = 0; i < this.order; i++)
        {
            if( rowSum(i) != this.magicNumber()) 
                return false;
        }
        return true;
    }
    
    //Checks the sum at row row
    private int rowSum(int row)
    {
        int sum = 0;
        for (int i = 0; i < this.order; i++)
        {
            sum += this.square[row][i];
        }
        return(sum);
    }
    
    /**
     * Checks the sum at each column.
     * @return true if sum == this.magicNumber()
     */
    public boolean colCheck()
    {
        for(int i = 0; i < this.order; i++)
        {
            if(this.colSum(i) != this.magicNumber())
                return false;
        }
        return true;
    }
    
    //Checks the sum at column
    private int colSum(int col)
    {
        int sum = 0;
        for (int i = 0; i < this.order; i++)
        {
            sum += this.square[i][col];
        }
        return sum;
    }

    /**
     * Checks the sum at the main diagonal.
     * @return true if sum == this.magicNumber()
     */
    public boolean mainDigCheck()
    {
        int check = 0;
        for (int i = 0; i < this.order; i++)
        {
            check += this.square[i][i];
        }
        return(check == this.magicNumber());
    }

    /**
     * Checks the sum at the secondary diagonal.
     * @return true if sum == this.magicNumber()
     */
    public boolean secDigCheck()
    {
        int check = 0;
        for (int i = 0; i < this.order; i++)
        {
            check += this.square[this.order-1-i][i];
        }
        return(check == this.magicNumber());
    }

    /**
     * Prints out the magic square.
     * @return String representation of this square
     */
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.order; i++)
        {
            sb.append(String.format("%5s", "====="));
        }
        sb.append("\n");
        for (int k = 0; k < this.order; k++)
        {
            for (int j = 0; j < this.order; j++)
            {
                sb.append(String.format("%5d", this.square[k][j]));
            }
            sb.append("\n");
        }
        for (int m = 0; m < this.order; m++)
        {
            sb.append(String.format("%5s", "====="));
        }
        return sb.toString();
    }
    
    /**
     * Compares two squares number by number.
     * @param other another MagicSquare object
     * @return true if every number is the same
     */
    public boolean equals(MagicSquare other)
    {
        for (int i = 0; i < this.order; i++) 
        {
            for(int k = 0; k < this.order; k++)
            {
                if(this.square[i][k] != other.square[i][k])
                    return false;
            }
        }
        return true;
    }
}














