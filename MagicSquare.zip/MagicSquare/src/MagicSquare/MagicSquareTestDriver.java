package MagicSquare;

public class MagicSquareTestDriver
{
    public static void main(String[] args)
    {
        MagicSquare ms5 = new MagicSquare(5);
        System.out.println("order: " + ms5.getOrder());
        System.out.println("magic number: " + ms5.magicNumber());
        System.out.println(ms5);
        System.out.println();

        MagicSquare ms = new MagicSquare(-2);
        System.out.println(ms);
        System.out.println();

        MagicSquare ms11 = new MagicSquare(11);
        if(ms11.isMagicSquare())
        {
            System.out.println("The following array is a magic square");
        }
        else
        {
            System.out.println("The following array of numbers is not a magic square");
        }
        System.out.println(ms11);
        System.out.println("magic number: " + ms11.magicNumber());
        return;
    }
}
